<?php


/*  Criando uma conexão com banco de dados */
//  Criando variaveis

$serverDB = "127.0.0.1:3306";  
// OU
//serverDB = "localhost:3306" ; 
//serverDB = "localhost;
$userDB = "root";
$passwordDB = "";
$nameDB = "dbStreaming_tii06"; 


//Criando a conexao MySql via Ojeto mysql
$conn = @new mysqli(        
    $serverDB, $userDB, $passwordDB, $nameDB  
);



if($conn ->connect_error){
    $resp = "Erro de conexão <br>";
    $resp = $resp.$conn ->connect_errno;
    $resp = $resp."<br>". "Erro: " .$conn ->connect_error;
    $resp = $resp."<br>";
    $resp = $nameDB;

}else  {
    $resp = "Sucesso! <br>";
    $resp = $resp . "Host informado :" . $conn ->host_info;
    $resp = $resp . "<br>" . "Protocolo versão :" .$conn -> protocol_version;
    

}

//texte de conexao visual na web
//echo $resp;
//echo '<br>';



