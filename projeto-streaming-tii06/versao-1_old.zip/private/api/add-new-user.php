<?php

// OBJETIVO: SISTEMA GRAVAR NOVO USUARIO NO BANCO DE DADOS


//criar variaveis que receberao  os dados dos formularios;
$userName = $_POST["user-name"];
$userEmail = $_POST["user-email"];
$userPassword = $_POST["user-password"];
$userConfirmPassword = $_POST["user-confirm-password"];

//testar  as variaveis para a verificação de conteudo nelas

if (
    (empty($userName))   || (empty($userEmail)) || (empty($userPassword)) || (empty($userConfirmPassword)) ||
    ($userName === "")   || ($userEmail === "")   || ($userPassword === "")     || ($userConfirmPassword === "")
) {
    $resp = "ERRO - algum campo esta vazio!";
    //exit;  //sai da programação o que esta abaixo nao sera executado
} else {
    include("../db/conn.php");

    // ordem: sempre primeiro CONSULTAR no DB, para entao GRAVAR no DB, ALTERA se necessario*
    // consultar SELECT * FROM
    // gravar/gravar  INSERT INTO () VALUES(NULL,)
    // alterar  UPDATE  SET  WHERE
    // deletar DELETE  FROM   WHERE
    
    $sql = "SELECT email, name FROM tblogin WHERE email='$userEmail' OR name ='$userName'";

    //consulta exc SQL acima
    $exc = $conn->query($sql);

    $emailDB = "";
    $nameDB = "";

    if ($exc->num_rows > 0) {
        while ($row = $exc->fetch_assoc()) {
            $emailDB = $row["email"];
            $nameDB = $row["name"];
        }
    }

    if (($emailDB === $userEmail) || ($nameDB === $userName)){
        $resp = "ERRO - Usuário já cadastrado !";
        $conn->close();
    } else {

        if ($userPassword !== $userConfirmPassword) {
            $resp = "ERRO - A senha não combina com a sua confirmação!";
            $conn->close();
        } else {
            //CRIPTOGRAFAR senha e hash
            $apiKey         = "maçã";  //chave de segurança interna que o programador ira criar para auxilar e dificulta a quebra de sigilo da senha. Usuario nao ve. ao testar sistema gera criptografia /hash para maça: f50ba1f649ca26b3791c80da19881851
            $apiKey         = (md5($apiKey));  //retorna a criptografia de valor 128bits/16bytes , em alto nivel . (baixo nivel em 0 e 1)
            //$qtd = strlen($apikey);  // saber qtos caracteres tem

            $userNameC      = (md5($userName));
            $userEmailC     = (md5($userEmail));
            $userPasswordC  = (md5($userPassword));

            $senhaDB        = (md5($apiKey.$userPasswordC.$userEmailC)); // hash de combinação
            $hashDB         = (md5($userNameC.$apiKey.$userPasswordC));  // outra hasd de combinação

            //echo "senha MD5:$senhaDB <br> senha hash :$hashDB";
            $custSenha = '09';   //recomendavel 08 e 09 customização
            $custHash  = '08';

            $saltSenha = $senhaDB;  // a customização vai saltar
            $saltHash  = $hashDB;

            //função crypt do php p/ senha com no minimo 60 CARACTERES
            $senhaDB = crypt($userEmailC, '$2b$' .$custSenha . '$'  .$saltSenha . '$');  //retorna a criptografia de valor 258bits/32bytes , em alto nivel . 

            // //função crypt do php p/ hash com 60 CARACTERES
            $hashDB  = crypt($userNameC, '$2b$' .$custHash . '$' .$saltHash . '$');  // na documentação de php/crypt usar '$2b$', '$', '$'

            // echo "senha crypt:<br> $senhaDB <br>";
            // echo "hash crypt: <br> $hashDB <br>";
            //echo $apiKey;

            $idAcl = 1;      // acesso master e 02 acesso CEO
            $idStatus = 2;   // acesso ativo   e 01 acesso inativo

            // $resp ="
            // name: $userName<br>
            // email: $userEmail<br>
            // senha: $senhaDB <br>
            // hash: $hashDB <br>
            // idACL: $idAcl<br>
            // idStatus: $idStatus<br>
            // ";


            //INSERIR/GRAVAR dados no banco para o login
       


            $sql = "INSERT INTO tblogin (idLogin, name, email, password, hash, idAcl, idStatus)
            VALUES (NULL, '$userName','$userEmail', '$senhaDB', '$hashDB','$idAcl','$idStatus')";

            $exc = $conn->query($sql);  

            if ($exc) {
                $resp = "Dados Gravados com Sucesso!! ";
            } else {
                $resp = "ERRO: ao Gravar os Dados !!";
                $resp = $resp . mysqli_error($conn);
            }


            $conn->close(); // Fechar o acesso ao Banco de Dados;
        }
    }
}


echo $resp;



