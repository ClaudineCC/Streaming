<?php

//... Porem a hash deverá acessar a pagina ‘password-reset-form.php’ com o envio via GET da hash e uma variável chamada ‘idRec’ como modelo abaixo.

$idRec = $_POST['idRec'];
$userNameEmail = $_POST['user-name-email'];
$userPassword = $_POST['user-password'];
$userConfPassword = $_POST['user-confirm-password'];


if (
    (empty($idRec))   || (empty($userNameEmail)) || (empty($userPassword)) || (empty($userConfPassword)) ||
    ($idRec === "") ||  ($userNameEmail === "") ||  ($userPassword === "") ||  ($userConfPassword === "")
) {
    $resp = "ERRO- Campos obrigatorios não preenchidos";
} else {
    include("../db/conn.php");

    $emailDB = "";
    $nameDB = "";
    $hashDB = "";

    $sql = "SELECT * FROM tblogin WHERE (email = '$userNameEmail' OR name = '$userNameEmail') AND hash = '$idRec'";

    $exc = $conn->query($sql);

    if ($exc->num_rows > 0) {
        while ($row = $exc->fetch_assoc()) {
            $idLoginDB = $row["idLogin"];
            $nameDB = $row["name"];
            $emailDB = $row["email"];
            $hashDB = $row["hash"];
        }
    }

    if ((($userNameEmail !== $emailDB) || ($userNameEmail !== $nameDB)) && ($idRec !== $hashDB)) {
        $resp = "ERRO - Usuário não registrado!";
        $conn->close();
    } else {
        if ($userPassword !== $userConfPassword) {     //verificar se as senhas são iguais
            $resp = "ERRO - Senhas não são iguais";
            $conn->close();
        } else {
            /* criptografia para senha e hash */
            //palavra chave
            $apiKey         = "maçã";  //chave de segurança interna que o programador ira criar para auxilar e dificulta a quebra de sigilo da senha. Usuario nao ve. ao testar sistema gera criptografia /hash para maça: f50ba1f649ca26b3791c80da19881851
            $apiKey         = (md5($apiKey)); //passa por criptografia

            $dateTime = new DateTime(null, new DateTimeZone('America/Sao_Paulo'));
            $formattedDate = $dateTime->format('Y-m-d H:i:s');

            $userName = $nameDB . $formattedDate;

            $userEmail = $emailDB;


            //criptografar senha e hash

            $userNameC      = (md5($userName));
            $userEmailC     = (md5($userEmail));
            $userPasswordC  = (md5($userPassword));

            $senhaDB    = (md5($apiKey . $userPasswordC . $userEmailC));
            $hashDB     = (md5($userNameC . $apiKey . $userPasswordC));

            $custSenha  = '09';
            $custHash   = '08';

            $saltSenha  = $senhaDB;
            $saltHash   = $hashDB;

            // Cript senha
            $senhaDB = crypt($userEmailC, '$2b$' . $custSenha . '$' . $saltSenha . '$');

            // Cript hash
            $hashDB = crypt($userNameC, '$2b$' . $custHash . '$' . $saltHash . '$');

            $sql = "UPDATE tblogin SET password = '$senhaDB', hash = '$hashDB' WHERE idLogin = $idLoginDB";

            if ($conn->query($sql) === TRUE) {
                $resp = 'Usuário atualizado com sucesso!';
            } else {
                $resp = 'Erro ao atualizar usuário: ' . $conn->error;
            }
            $conn->close();
        }
    }
}
echo $resp;
