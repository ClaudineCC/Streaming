<?php

//  VALIDAR/AUTENTICAR  = conferir usuario e senha cadastrados no formulario LOGIN 

//crie um arquivo com nome de 'validation-user.php' na pasta 'private/api'
//aponte o action do formulario do arquivo 'inde.php' para este arquivo criado.


$userLoginEmail = $_POST['user-login-email'];  
$userPassword = $_POST['user-password'];

//echo $userLoginEmail;   //texte 
//echo $userPassword;     //texte


//1 texte so para saber se os dados estao chegando vazio
if(
    ((empty($userLoginEmail)) || $userLoginEmail === "") ||
    ((empty($userPassword)) || $userPassword === "")){
    $resp = "ERRO - Algum campo esta vazio!";
}else{
    include("../db/conn.php");

    $sql = "SELECT * FROM tblogin WHERE (name ='$userLoginEmail' OR email ='$userLoginEmail')";
    
    $exc = $conn->query($sql); //chamada da coxexao

    if (!($exc->num_rows > 0)) {    // texte para saber se usuario existe. 
        $resp = "Erro - Usuário ou senha invalida";
        $conn->close();
    }else{ 
            while($row = $exc->fetch_assoc()){
            $userEmail = $row['email'];
            $DBpass = $row['password'];
        }

        // Criptografia se senha e hash
        $apiKey         = "maçã";
        $apiKey         = (md5($apiKey));

        $userEmailC     = (md5($userEmail));
        $userPasswordC  = (md5($userPassword));

        $senhaDB    = (md5($apiKey.$userPasswordC.$userEmailC));
    
        $custSenha  = '09';
        $saltSenha  = $senhaDB;

        $senhaDB = crypt($userEmailC, '$2b$'.$custSenha.'$'.$saltSenha.'$');


        if(!($senhaDB == $DBpass)){
            $resp = "ERRO - Usuário ou senha invalida!";
            $conn->close();
        }else{
            $resp = "Ok usuario ou email valido!";
            $conn->close();
        }
    }
}

echo $resp;
?>



