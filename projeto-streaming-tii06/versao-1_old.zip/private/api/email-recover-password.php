<?php

// Após gravar o login no banco de dados   = user.register.php
// e depois gerado o formulário de recuperar a senha. = recover-password.php

// Na pagina do formulário ‘recover-password-form.php’, o usuário deve fornecer o email ou nome de usuario e quando clicar no botão ‘Recuperar senha’, será enviado para o arquivo ‘email-recover-password.php’.
// Com o nome do usuário seu email e a hash. Porem a hash deverá acessar a pagina ‘password-reset-form.php’ com o envio via GET da hash e uma variável chamada ‘idRec’ como modelo abaixo.


// Com o email enviado realiza uma consulta no banco de dados e recupere em variáveis os seguintes dados: name, email, hash, 


include("../db/conn.php");

$userLogin = $_POST['user-name-email'];


$sql = "SELECT name,email, hash  FROM tblogin WHERE( name='$userLogin' OR email ='$userLogin')";

//consulta exc SQL acima
$exc = $conn->query($sql);

$nameDB="";
$emailDB="";


// Teste para saber se o email enviado pelo formulário é igual ao email  ou o name do banco de dados se for verdadeiro imprima esta saída abaixo:


    if ($exc->num_rows > 0) {
        while ($row = $exc->fetch_assoc()) {
            $nameDB = $row["name"]; 
            $emailDB = $row["email"];
            $hashDB = $row["hash"];
        } 
    }
    
if (!(($userLogin === $nameDB)) || (($userLogin===$emailDB))) {
    $resp = "Email ou usuário não confere, verifique novamente";
    $conn->close();

} else {        //$resp= "ok!"; //teste

$url = "http://localhost/projeto-streaming-tii06/public-html/password-reset-form.php?idRec=$hashDB";
$resp= "
    <h2>Recuperar Senha</h2>
    <p>Caro usuário você solicitou a recuperação de senha do Streaming?</p>
    <p>Através do email <b> $emailDB </b> e  usuário:<b> $nameDB </b></p>
    <p>Segue o link abaixo para recupera a senha clique ou se preferir copie o endereço e cole em seu navegador</p>
    <p><a href ='$url' target='_blank'> $url</a></p>
    <p>Porem caso não tenha solicitado desconsidere esse email</p>
    <h3>Grato equipe Streaming!!!</h3>";
    $conn->close();

   }

    echo $resp;
?>