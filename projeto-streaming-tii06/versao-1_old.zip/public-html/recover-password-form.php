<?php

//Na pagina do formulário ‘recover-password-form.php’, o usuário deve fornecer o email ou usuario e quando clicar no botão ‘Recuperar senha’, será enviado para o arquivo ‘email-recover-password.php’.

$pageName =" Recuperar a senha usuário";  // TITULO URL
include("inc/head.inc.php"); 
?>


<main>
<!-- FRONT - FORMULARIO PARA DIGITAR NOVA SENHA  -->    

<h1>Recuperar nova senha de acesso</h1>
<form method="post"action="../private/api/email-recover-password.php"> <!-- sql - INSERT --> 



<label>Digite o email ou usuario:</label><br>
<input type="text" name="user-name-email"  required placeholder="digite seu email ou usuario..."><br> 


<input type="submit" value="Recuperar Senha" >

</form>
<hr>



<p>
    <a href="user-register.php">Cadastrar usuário</a> | <a href="inde.php">Login</a>
</p>




</main>
<?php include("inc/footer.inc.php");?>






