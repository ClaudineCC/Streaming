<?php


define("TITLE", "Streaming - Painel Administrativo");  //palavra reservada definicao


?>