<?php

//... Porem a hash deverá acessar a pagina ‘password-reset-form.php’ com o envio via GET da hash e uma variável chamada ‘idRec’ como modelo abaixo.

$idRec = $_GET['idRec'];

if (((empty($idRec))   || ($idRec === ""))){
    $resp = "ERRO - idRec vazio!";
}else{
    $sql = "SELECT email, hash FROM tblogin WHERE hash ='$idRec'";

    include("../private/db/conn.php");

    $exc = $conn->query($sql);

    $emailDB = "";
    $hashDB = "";
    $idUserDB = "";

    if ($exc->num_rows > 0) {
        while ($row = $exc->fetch_assoc()) {
            $emailDB = $row["email"];
            $hashDB = $row["hash"];
        }
        $conn->close();
    }

    if($idRec !== $hashDB) {
        $resp = "ERRO - o idREc não combina com a recuperação de senha verifique!";
        echo $resp;
        $conn->close();
    } else {
        ?>
        <?php

        $pageName = "Recuperar senha de usuario";
        include("inc/head.inc.php");
        ?>



        <main>
            <!-- FORMULARIO  PARA DIGITAR  NOVA SENHA  -->

            <h1>Recuperar senha de Usuário</h1>
            <form method="post" action="../private/api/update-password-reset.php">     <!-- sql - INSERT -->
                <input type="hidden" name="idRec" value="<?= $hashDB ?>">

                <label>Email/Usuário</label><br>
                <input type="text" name="user-name-email" required placeholder="digite seu email ou usuário.."><br>

                <label>Nova Senha:</label><br>
                <!--depois muda o type para password-->
                <input type="text" name="user-password" required placeholder="digite a nova senha..."><br>

                <label>Confirmar senha:</label><br>
                <input type="text" name="user-confirm-password" required placeholder="digite a confirmação da nova senha..."><br>

                <input type="submit" value="Recuperar Senha">

            </form>
            <hr>

            <p>
                <a href="inde.php">Login</a> |
                <a href="user-register.php">Cadastrar usuário</a>
            </p>

        </main>


<?php

        include("inc/footer.inc.php");
    }
}


?>