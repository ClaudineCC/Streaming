<?php
$pageName = "Entre e curta";  // primeiro criar variavel
include("inc/head.inc.php");   
?>


<main>
<!-- FRONT - FORMULARIO  CADASTRAR USUARIO -->
<h1>Cadastrar usuário</h1>
<form method="post"action="../private/api/add-new-user.php">

<label>Usuário:</label><br>
<input type="text" name="user-name" required placeholder="digite seu nome..."><br>  <!--depois muda o type para o password-->

<label>Email:</label><br>
<input type="text" name="user-email" required placeholder="digite seu email..."><br>  <!--depois muda o type para o password--> 


<label>Senha:</label><br>
<input type="text" name="user-password"  required placeholder="digite sua senha..."><br>

<label>Confirmar senha:</label><br>
<input type="text" name="user-confirm-password" required placeholder ="digite a confirmação da sua senha..."><br>

<input type="submit" value="Cadastrar" >

</form>
<hr>

<p>
    <a href="recover-password-form.php">Recuperar senha</a> | <a href="inde.php">Login</a>
</p>


<!-- dados abaixo irao para arquivo add-new-user.php
$userName = $_POST["user-name"];
$userEmail= $_POST["user-email"];
$userPassword = $_POST["user-password"];
$userConfirmPassword = $_POST["user-confirm-password"]; -->




</main>


<?php  include ("inc/footer.inc.php");?>