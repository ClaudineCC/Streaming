<?php

$pageName = "Entre e curta";  // TITULO URL

include("inc/head.inc.php");   // esse include trara a pagina HEAD para dentro do index

?>


<main>
<!-- FORMULARIO LOGIN-->     

<h1>Login</h1>
<form method="post"action="../private/api/validation-user.php">  <!-- sql - INSERT --> 

<label>Usuário:</label><br>
<input type="text" name="user-login-email" required placeholder="digite seu email ou usuário..."><br>  <!--depois muda o type para o password-->

<label>Senha:</label><br>
<input type="text" name="user-password"  required placeholder="digite sua senha..."><br>

<input type="submit" value="Entre e curta" >

</form>
<hr>

<p>
    <a href="recover-password-form.php">Recuperar senha</a> | <a href="user-register.php">Cadastrar usuário</a>
</p>




</main>


<?php  include ("inc/footer.inc.php");?>  <!--esse include trara a pagina FOOTER para dentro do index -->
